# Hitwicket-Software-Project
Build a turn based chess like game, a program that accepts commands to make moves over the cli (command line interface)
